#  폴더 src3 참조하기

#   🥯  react-router-dom  설치하기   ==> 페이지를 나누는 역할

#   공식 사이트 주소 - https://reactrouter.com/en/main/start/tutorial

# 1) 설치하기  --     npm install react-router-dom 

![image](https://github.com/understanding963852/604react/assets/60366769/af3c99a5-63f2-45b2-b046-08a5bf590f71)


![image](https://github.com/understanding963852/604react/assets/60366769/4e44deae-8ece-4373-9048-13e858aaf7dd)

![image](https://github.com/understanding963852/604react/assets/60366769/35f68bbe-1536-495f-b815-147ceb4bb78a)

![image](https://github.com/understanding963852/604react/assets/60366769/925876fd-fa68-4098-9261-6d015a286394)


# 🚛 링크로 연결해서 페이지로 갈때

# Link는 a 태그로 변환된다. 라우터간에 이동할수 있게 도와주는 링크  

![image](https://github.com/understanding963852/604react/assets/60366769/1800d3b2-0c73-417f-8726-0362de99c48a)

# 🐤 버튼을 클릭해서 페이지로 갈때(함수안에서 사용하는 방법)


# 

