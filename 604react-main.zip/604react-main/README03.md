# component 만들기
![image](https://github.com/understanding963852/604react/assets/60366769/f55188c7-722a-41e0-948c-4c211cd443b2)


![image](https://github.com/understanding963852/604react/assets/60366769/ee18b695-4a77-41cf-b196-1fd742825f6d)

# react에서 emmit적용하기--> 태그 자동 완성기능

![image](https://github.com/understanding963852/604react/assets/60366769/0ad1c6f9-f15e-471c-9bef-ef065c9b8828)

```
"emmet.excludeLanguages": {"javascript":"javascriptreact"}
```

![image](https://github.com/understanding963852/604react/assets/60366769/9a26c042-60e6-4222-bdb0-346b2cc53922)

![image](https://github.com/understanding963852/604react/assets/60366769/15e602c7-6fb9-4598-ae6b-1c3ba7ddef76)



# 기본 다시 해보기
![image](https://github.com/understanding963852/604react/assets/60366769/553a842c-96fa-4818-a176-d18e4a499806)

